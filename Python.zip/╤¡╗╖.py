for s in "BIT":
    print("循环进行中: " + s)
else:
    s = "循环正常结束"
print(s)
